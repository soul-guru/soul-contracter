"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Contracts = void 0;
const ContractRaw_1 = require("../schemas/ContractRaw");
const lodash_1 = __importDefault(require("lodash"));
const crypto_1 = __importDefault(require("crypto"));
var Contracts;
(function (Contracts) {
    function generateSecureString() {
        return require("crypto").randomBytes(48).toString("hex");
    }
    async function getAll() {
        return await ContractRaw_1.ContractRaw.find({}).lean().exec();
    }
    Contracts.getAll = getAll;
    async function getAllByOwner(owner) {
        return await ContractRaw_1.ContractRaw.find({ owner }).lean().exec();
    }
    Contracts.getAllByOwner = getAllByOwner;
    async function getSource(botId) {
        return await ContractRaw_1.ContractRaw.findOne({ botId }).lean().exec();
    }
    Contracts.getSource = getSource;
    async function create(botId, owner) {
        return lodash_1.default.first(await ContractRaw_1.ContractRaw.insertMany([
            {
                id: generateSecureString(),
                httpOverKey: generateSecureString(),
                botId: botId,
                owner: owner,
                mainBranch: "main",
                branches: [],
            },
        ]));
    }
    Contracts.create = create;
    async function count(botId) {
        return await ContractRaw_1.ContractRaw.countDocuments({
            botId: botId,
        });
    }
    Contracts.count = count;
    async function decryptInputForContract(botId, content) {
        const algorithm = "aes256";
        const key = lodash_1.default.get(await ContractRaw_1.ContractRaw.findOne({ botId }).lean().exec(), "httpOverKey", null);
        if (!key) {
            return null;
        }
        const code = content;
        const decipher = crypto_1.default.createDecipher(algorithm, key);
        return decipher.update(code, "hex", "utf8") + decipher.final("utf8");
    }
    Contracts.decryptInputForContract = decryptInputForContract;
    async function pushContractSource(branch = "main", source = "", botId) {
        var result = await ContractRaw_1.ContractRaw.updateOne({
            "branches.name": branch,
            botId,
        }, {
            $set: {
                "branches.$.source": source,
            },
            $inc: {
                version: 1,
            },
        })
            .lean()
            .exec();
        if (result.matchedCount == 1 && result.matchedCount == 1) {
            return true;
        }
        if (result.matchedCount == 0) {
            return ((await ContractRaw_1.ContractRaw.updateOne({
                botId,
            }, {
                $push: {
                    branches: [{ source, name: branch, version: 1 }],
                },
            })
                .lean()
                .exec()).modifiedCount == 1);
        }
        return false;
    }
    Contracts.pushContractSource = pushContractSource;
})(Contracts || (exports.Contracts = Contracts = {}));
//# sourceMappingURL=contracts.js.map