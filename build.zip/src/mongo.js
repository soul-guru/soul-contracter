"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.connection = void 0;
const mongoose = require("mongoose");
mongoose.connect(process.env.MONGO_HOST || "mongodb://127.0.0.1:3131/i2-mcr");
exports.connection = mongoose;
//# sourceMappingURL=mongo.js.map