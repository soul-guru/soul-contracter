console.log(1);
//# sourceMappingURL=b.js.map