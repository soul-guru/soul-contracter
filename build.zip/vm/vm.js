"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const boot_1 = __importDefault(require("./boot"));
const node_fs_1 = require("node:fs");
const ivm = require("isolated-vm");
const node_events_1 = __importDefault(require("node:events"));
const clickhouse_1 = require("../src/clickhouse");
const fs_1 = require("fs");
const axios_1 = __importDefault(require("axios"));
const sync_fetch_1 = __importDefault(require("sync-fetch"));
class VMEmitter extends node_events_1.default {
}
class VM {
    bootableIsolated = (0, boot_1.default)();
    sysFile = process.cwd() + "/vm/sys.js";
    context = undefined;
    botId;
    contractId;
    memory = 32;
    emitter = new VMEmitter();
    constructor(contractId, botId, memory) {
        this.contractId = contractId;
        this.botId = botId;
        this.memory = memory;
        if (!(0, fs_1.existsSync)(this.sysFile)) {
            throw Error("sys.js not found");
        }
    }
    isolate = new ivm.Isolate({
        memoryLimit: this.memory,
        inspector: true,
        onCatastrophicError: () => {
            process.abort();
        },
    });
    metric() {
        return this.isolate.getHeapStatisticsSync();
    }
    workTime() {
        return this.isolate.cpuTime;
    }
    async stop() {
        if (!this.isolate.isDisposed) {
            return this.isolate.dispose();
        }
        return null;
    }
    createContext() {
        const contextSync = this.isolate.createContextSync();
        return this.fillContext(contextSync);
    }
    async fillContext(context) {
        await context.global.set("log", console.log);
        await context.global.set("network_request_json", (url, params) => {
            if (["jar1", "jar2", "jar3"].includes((new URL(url)).host)) {
                return null;
            }
            return Object((0, sync_fetch_1.default)(url, params).json());
        });
        await context.global.set("network_request_raw", (url, params) => {
            return String((0, sync_fetch_1.default)(url, params).text());
        });
        context.evalClosureSync(`
      globalThis.console = {
        log: $0,
      }
      
      globalThis.answer = {
        plainText: $1,
      }
    `, [
            (...args) => this.emitter.emit("log", args),
            ({ dialogId, text }) => {
                axios_1.default
                    .post(process.env.I2_CLUSTER_FLOW +
                    "/service/dialogs/resolve/" +
                    dialogId, {
                    markup: [{ plainText: text }],
                })
                    .catch(console.error);
            }
        ]);
        return context;
    }
    async compile(source) {
        this.context = await this.createContext();
        const sysRunnable = await this.isolate.compileScript((0, node_fs_1.readFileSync)(this.sysFile).toString("utf-8"));
        await sysRunnable.run(this.context);
        const compileRunnable = await this.isolate.compileScript(source);
        await compileRunnable.run(this.context);
        return this.context;
    }
    async bootstrap() {
        this.bootableIsolated.vmEmitter.once("boot", () => {
            this.captureErrorRunnable(this.context.evalClosure(`safeSignal('onBoot', $export)`));
        });
        this.bootableIsolated.vmEmitter.on("message", (object) => {
            const obj = JSON.stringify(object);
            this.captureErrorRunnable(this.context.evalClosure(`safeSignal('onMessage', $export, JSON.parse('${obj}'))`));
        });
    }
    async signal(signal, props = null) {
        return this.bootableIsolated.vmEmitter.emit(signal, props);
    }
    captureErrorRunnable(promise, ignoreError = true) {
        return new Promise(async (resolve, reject) => {
            try {
                return resolve(await promise);
            }
            catch (error) {
                if (error instanceof Error) {
                    clickhouse_1.ClickHouse.insertContractError(error, this.botId, this.contractId, "EVENT").catch(console.error);
                }
                !ignoreError && reject(error);
            }
        });
    }
}
exports.default = VM;
//# sourceMappingURL=vm.js.map