"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const node_events_1 = __importDefault(require("node:events"));
class VMEmitter extends node_events_1.default {
}
function getBootableISO() {
    const vmEmitter = new VMEmitter();
    return {
        vmEmitter,
    };
}
exports.default = getBootableISO;
//# sourceMappingURL=boot.js.map